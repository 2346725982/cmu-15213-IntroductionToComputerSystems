


int bitOr(int, int);
int test_bitOr(int, int);
int tmin();
int test_tmin();
int negate(int);
int test_negate(int);
int getByte(int, int);
int test_getByte(int, int);
int divpwr2(int, int);
int test_divpwr2(int, int);
int logicalShift(int, int);
int test_logicalShift(int, int);
int isPositive(int);
int test_isPositive(int);
int isLess(int, int);
int test_isLess(int, int);
int bang(int);
int test_bang(int);
int isPower2(int);
int test_isPower2(int);
int ilog2(int);
int test_ilog2(int);
unsigned float_half(unsigned);
unsigned test_float_half(unsigned);
unsigned float_i2f(int);
unsigned test_float_i2f(int);
